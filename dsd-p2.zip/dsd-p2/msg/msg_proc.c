/* msg_proc.c: Implementacion del procedimiento remoto*/

#include <stdio.h>
#include "msg.h" /* el archivo lo genera rpcgen */

int * printresult_1_svc (entero1, operador, entero2, req)
  char ** entero1;
  char ** operador;
  char ** entero2;
  struct svc_req * req; /* detalles de la llamada */

  {
    static int result; /* es obligatorio que sea estatica */
    switch (operador[0]) {
      case '+': result = entero1[0] + entero2[0];
      break;

      case '-': result = entero1[0] - entero2[0];
      break;

      case 'x': result = entero1[0] * entero2[0];
      break;

      case '/': result = entero1[0] / entero2[0];
      break;
    }
    /*
    FILE *f;
    f = fopen("/dev/console", "w");
    if (f == (FILE *)NULL) {
      result = 0 ;
      return (&result);
    }*/
    printf("%i\n", result);
    //fclose(f);
    //result = 1;
    return (&result);
  }
