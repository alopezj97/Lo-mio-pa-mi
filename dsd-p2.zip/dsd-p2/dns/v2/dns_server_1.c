#include "dns.h"

typedef struct Equipo {
	char * nombre ;
	char * ip ;
};

/*
typedef struct Nodo {
	char * programa ;
	char * version ;
};
*/

typedef struct Red {
	char * nombre ;
	struct Equipo equipos[10];
	int num_equipos ;
	//struct Nodo padre ;
	//struct Nodo hijos[3] ;
};

struct Red mi_red ;

/*
char ** consultar_dns_sup(char* nombre) {
	CLIENT * clnt ;
	static char * resultado ;

	#ifndef DEBUG
		clnt = clnt_create("localhost", mi_red.padre.programa, mi_red.padre.version, "udp");
		if (clnt == NULL) {
			clnt_pcreateerror("localhost");
			exit(1);
		}
	#endif

	resultado = *consultar_1(nombre, clnt);

	if (resultado == (char*) NULL)
		clnt_perror(clnt, "call failed");

	#ifndef DEBUG
		clnt_destroy(clnt);
	#endif

	return &resultado;
}
*/

int buscar (char * nombre) {

	for (int i = 0 ; i < mi_red.num_equipos; i++){
		//printf("%s\n", mi_red.equipos[i].nombre);
		if (strcmp(nombre, mi_red.equipos[i].nombre) == 0)
			return i ;
	}

	return -1;
}

char **
dns1_consultar_1_svc(char *nombre,  struct svc_req *rqstp)
{

	static char * result;
	int index ;
	result = "Domain Name Not Found";

	index = buscar(nombre);

	if (index != -1)
		result = mi_red.equipos[index].ip;
/*
	else {
		if (mi_red.padre != (Nodo) NULL)
			result = *consultar_dns_sup(nombre);
	}
*/

	return &result;
}

char **
dns1_registrar_1_svc(char *nombre, char *ip,  struct svc_req *rqstp)
{
	static char * result;

	if (buscar(nombre) != -1) {
		result = "[ERROR] Domain Name Already Exists";
		return &result;
	}

	if (mi_red.num_equipos == 10) {
		result = "[ERROR] Limite de direcciones alcanzado";
		return &result;
	}

	mi_red.equipos[mi_red.num_equipos].nombre = malloc(sizeof(*nombre));
	mi_red.equipos[mi_red.num_equipos].ip = malloc(sizeof(*ip));

	strcpy(mi_red.equipos[mi_red.num_equipos].nombre, nombre);
	strcpy(mi_red.equipos[mi_red.num_equipos].ip, ip);

	if (strcmp(nombre, mi_red.equipos[mi_red.num_equipos].nombre) != 0)
		result = "[ERROR] Domain Name couldn't be saved";
	else {
		if (strcmp(ip, mi_red.equipos[mi_red.num_equipos].ip) != 0)
			result = "[ERROR] IP address couldn't be saved";
		else
			result = "IP registrada correctamente";
	}

	mi_red.num_equipos++;

	for (int i = 0 ; i < mi_red.num_equipos; i++)
		printf("%s - %s\n", mi_red.equipos[i].nombre, mi_red.equipos[i].ip);

	return &result;
}

char **
dns1_baja_1_svc(char *nombre,  struct svc_req *rqstp)
{
	static char * result;

	int index = buscar(nombre);

	if (index == -1) {
		result = "[ERROR] Domain Name Not Found";
		return &result;
	}

	for (int i = index; i < mi_red.num_equipos-1 ; i++) {
		mi_red.equipos[i] = mi_red.equipos[i+1];
	}

	mi_red.num_equipos--;
	result = "IP eliminada correctamente";

for (int i = 0 ; i < mi_red.num_equipos; i++)
		printf("%s - %s\n", mi_red.equipos[i].nombre, mi_red.equipos[i].ip);

	return &result;
}

void init (char * nombre) {
	struct Equipo gg = {"google.com", "127.217.3.110"};

	mi_red.equipos[0] = gg;
	mi_red.num_equipos = 1;

	mi_red.nombre = nombre ;
	//struct Nodo padre = {"DNSPROG1", "DNSVERS"};
	//struct Nodo hijo2 = {"DNSPROG2", "DNSVERS"};
	//struct Nodo hijo3 = {"DNSPROG3", "DNSVERS"};

	//mi_red.padre = padre ;
	//mi_red.hijos[0] = hijo2 ;
	//mi_red.hijos[1] = hijo3 ;

}
