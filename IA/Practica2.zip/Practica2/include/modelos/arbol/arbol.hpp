#ifndef ARBOL_H
#define ARBOL_H

#include "obj3dlib.hpp"


class Arbol3D : public Objeto3D {
private:
  /* data */
public:
  Arbol3D();
  ~Arbol3D();

};

#endif
